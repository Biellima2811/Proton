package com.mycompany.proton;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;                      // Representa uma data (usada nos DatePickers)
import java.util.ResourceBundle;
import javafx.beans.property.SimpleIntegerProperty; // Propriedade observável para inteiros (TableView)
import javafx.beans.property.SimpleStringProperty;  // Propriedade observável para strings (TableView)
import javafx.collections.FXCollections;            // Cria listas observáveis para combos e tabelas
import javafx.collections.ObservableList;           // Lista que notifica automaticamente a UI
import javafx.event.ActionEvent;                    // Evento de ação (cliques em botões)
import javafx.fxml.FXML;                            // Anotação para vinculação com o arquivo FXML
import javafx.fxml.Initializable;                  // Interface para inicialização do controlador
import javafx.scene.control.Alert;                  // Diálogos de alerta
import javafx.scene.control.ComboBox;               // Caixa de seleção suspensa
import javafx.scene.control.DatePicker;             // Campo de seleção de data
import javafx.scene.control.TableColumn;            // Coluna de uma tabela
import javafx.scene.control.TableView;              // Componente de tabela
import javafx.scene.control.TextField;              // Campo de texto comum
import javafx.stage.Stage;                          // Janela do JavaFX

/**
 * Controlador do formulário de Cliente Compartilhado.
 *
 * Tela dividida em três abas: Aba 1 – Dados Gerais do Cliente Aba 2 – Cadastro
 * de e‑mails dos usuários Aba 3 – Dados dos bancos de dados associados
 *
 * Permite inclusão, edição e visualização (somente leitura) dos registros. As
 * informações são persistidas nas tabelas: clientes_compartilhados
 * bancos_nuvem_compartilhada usuarios_nuvem_compartilhada
 */
public class FormClienteCompartilhadoController implements Initializable {

    // ==================== ABA 1: DADOS GERAIS ====================
    @FXML
    private ComboBox<String> cbSegmento;         // Segmento de mercado (Contábil, Corporativo)
    @FXML
    private ComboBox<String> cbTipoNuvem;        // Tipo de nuvem (Compartilhada, Dedicada)
    @FXML
    private DatePicker dpDataCriacao;            // Data de criação do cadastro
    @FXML
    private ComboBox<String> cbPod;              // Número do POD (1 a 8)
    @FXML
    private TextField txtRazaoSocial;            // Razão social da empresa
    @FXML
    private TextField txtCpfCnpj;                // CPF ou CNPJ
    @FXML
    private TextField txtCodAg;                  // Código da agência / contrato
    @FXML
    private TextField txtPastaRede;              // Caminho da pasta de rede
    @FXML
    private TextField txtSistemas;               // Sistemas utilizados
    @FXML
    private ComboBox<String> cbStatus;           // Status do cliente (Ativo, Pendente, etc.)
    @FXML
    private ComboBox<String> cbBanco;            // Tipo de base de dados (SQL, Firebird, FB e SQL)
    @FXML
    private TextField txtContato;                // Nome do contato responsável
    @FXML
    private TextField txtTelefone;               // Telefone de contato
    @FXML
    private ComboBox<String> cbOrigem;           // Origem do cliente (Novo, Base, Novo eSocial)
    @FXML
    private TextField txtUsuarios;               // Quantidade de usuários
    @FXML
    private TextField txtEmail;                  // E‑mail de contato
    @FXML
    private TextField txtRazaoAntiga;            // Razão social / CNPJ anterior (se houve alteração)

    // ==================== ABA 2: CADASTRO DE EMAILS ====================
    @FXML
    private TextField txtEmailUsuario;           // Campo para digitar o e‑mail do usuário
    @FXML
    private TableView<EmailItem> tabelaEmails;   // Tabela que lista os e‑mails cadastrados
    @FXML
    private TableColumn<EmailItem, Integer> colUserNum;   // Coluna com o número sequencial
    @FXML
    private TableColumn<EmailItem, String> colUserEmail;  // Coluna com o e‑mail
    private ObservableList<EmailItem> listaEmailsTemporaria = FXCollections.observableArrayList(); // Itens da tabela

    // ==================== ABA 3: DADOS DE BANCO DE DADOS ====================
    @FXML
    private TextField txtDbServidor;             // IP/nome do servidor do banco
    @FXML
    private TextField txtDbNome;                 // Nome do banco de dados
    @FXML
    private TextField txtDbConexao;              // Caminho/conexão adicional
    @FXML
    private ComboBox<String> cbDbSgbd;           // SGBD (Firebird, MSSQL)
    @FXML
    private ComboBox<String> cbUserBanco;        // Usuário do banco (SYSDBA, cliente.sql, sa)
    @FXML
    private TextField txtSenhaBanco;             // Senha do banco

    @FXML
    private TableView<BancoItem> tabelaBancos;   // Tabela que lista os bancos associados
    @FXML
    private TableColumn<BancoItem, String> colBancoServidor;   // Coluna Servidor
    @FXML
    private TableColumn<BancoItem, String> colBancoNome;       // Coluna Nome do Banco
    @FXML
    private TableColumn<BancoItem, String> colBancoSgbd;       // Coluna SGBD
    @FXML
    private TableColumn<BancoItem, String> colBancoCaminho;    // Coluna Caminho/Conexão
    @FXML
    private TableColumn<BancoItem, String> colBancoUsuario;    // Coluna Usuário
    @FXML
    private TableColumn<BancoItem, String> colBancoSenha;      // Coluna Senha
    private ObservableList<BancoItem> listaBancosTemporaria = FXCollections.observableArrayList(); // Itens da tabela de bancos

    // ==================== CONTROLE DE MODO ====================
    private boolean modoVisualizacao = false;    // true = campos bloqueados (somente leitura)
    private boolean modoEdicao = false;          // true = alterando registro existente
    private Integer idClienteEdicao = null;      // ID do cliente quando estiver editando

    /**
     * Inicializa os ComboBoxes com as listas de valores possíveis. Configura as
     * colunas das duas TableViews. Executado automaticamente após o
     * carregamento do FXML.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Preenche os ComboBoxes
        if (cbSegmento != null) {
            cbSegmento.setItems(FXCollections.observableArrayList("Contábil", "Corporativo"));
        }
        if (cbTipoNuvem != null) {
            cbTipoNuvem.setItems(FXCollections.observableArrayList("Compartilhada", "Dedicada"));
        }
        if (cbStatus != null) {
            cbStatus.setItems(FXCollections.observableArrayList("Ativo", "Ativando", "Desativado", "Pendente"));
        }
        if (cbBanco != null) {
            cbBanco.setItems(FXCollections.observableArrayList("SQL", "Firebird", "FB e SQL"));
        }
        if (cbOrigem != null) {
            cbOrigem.setItems(FXCollections.observableArrayList("Novo", "Base", "Novo Esocial"));
        }
        if (cbPod != null) {
            cbPod.setItems(FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8"));
        }
        if (cbDbSgbd != null) {
            cbDbSgbd.setItems(FXCollections.observableArrayList("Firebird", "MSSQL"));
        }
        if (cbUserBanco != null) {
            cbUserBanco.setItems(FXCollections.observableArrayList("SYSDBA", "cliente.sql", "sa"));
        }

        // Configura a tabela de e‑mails
        if (colUserNum != null) {
            colUserNum.setCellValueFactory(cellData -> cellData.getValue().numeroProperty().asObject());
        }
        if (colUserEmail != null) {
            colUserEmail.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        }
        if (tabelaEmails != null) {
            tabelaEmails.setItems(listaEmailsTemporaria);
        }

        // Configura a tabela de bancos
        if (colBancoServidor != null) {
            colBancoServidor.setCellValueFactory(cellData -> cellData.getValue().servidorProperty());
        }
        if (colBancoNome != null) {
            colBancoNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
        }
        if (colBancoSgbd != null) {
            colBancoSgbd.setCellValueFactory(cellData -> cellData.getValue().sgbdProperty());
        }
        if (colBancoCaminho != null) {
            colBancoCaminho.setCellValueFactory(cellData -> cellData.getValue().conexaoProperty());
        }
        if (colBancoUsuario != null) {
            colBancoUsuario.setCellValueFactory(cellData -> cellData.getValue().usuarioProperty());
        }
        if (colBancoSenha != null) {
            colBancoSenha.setCellValueFactory(cellData -> cellData.getValue().senhaProperty());
        }
        if (tabelaBancos != null) {
            tabelaBancos.setItems(listaBancosTemporaria);
        }
    }

    /**
     * Cria e retorna uma conexão JDBC com o banco de dados usando as
     * configurações salvas.
     */
    private Connection conectar() throws SQLException {
        String urlConexao = String.format("jdbc:postgresql://%s:5432/%s",
                ConfigBancoController.getIpServidor(), ConfigBancoController.getNomeBanco());
        return DriverManager.getConnection(urlConexao,
                ConfigBancoController.getUsuarioBD(), ConfigBancoController.getSenhaBD());
    }

    // ==========================================
    // GERENCIAMENTO DA MINI-TABELA DE BANCOS
    // ==========================================
    /**
     * Adiciona um novo banco à tabela temporária. Valida se servidor, nome e
     * SGBD foram preenchidos.
     */
    @FXML
    private void adicionarBanco(ActionEvent event) {
        if (txtDbServidor.getText() == null || txtDbServidor.getText().trim().isEmpty()
                || txtDbNome.getText() == null || txtDbNome.getText().trim().isEmpty()
                || cbDbSgbd.getValue() == null || cbDbSgbd.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso",
                    "Preencha IP do Servidor, Nome do Banco e SGBD para adicionar à lista.",
                    Alert.AlertType.WARNING);
            return;
        }

        // Cria um novo BancoItem com os dados informados e adiciona à lista
        listaBancosTemporaria.add(new BancoItem(
                txtDbServidor.getText().trim(),
                txtDbNome.getText().trim(),
                txtDbConexao.getText() != null ? txtDbConexao.getText().trim() : "",
                cbDbSgbd.getValue().trim(),
                cbUserBanco.getValue() != null ? cbUserBanco.getValue().trim() : "N/A",
                txtSenhaBanco.getText() != null ? txtSenhaBanco.getText().trim() : "",
                cbSegmento.getValue() != null ? cbSegmento.getValue().trim() : "Corporativo"
        ));

        // Limpa os campos para uma nova digitação
        txtDbServidor.clear();
        txtDbNome.clear();
        txtDbConexao.clear();
        txtSenhaBanco.clear();
    }

    /**
     * Remove o banco selecionado na tabela da lista temporária.
     */
    @FXML
    private void removerBanco(ActionEvent event) {
        BancoItem selecionado = tabelaBancos.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            listaBancosTemporaria.remove(selecionado);
        }
    }

    // ==========================================
    // GERENCIAMENTO DE E-MAILS
    // ==========================================
    /**
     * Adiciona um e‑mail à tabela, respeitando o limite definido pela
     * Quantidade de Usuários informada na Aba 1.
     */
    @FXML
    private void inserirEmail(ActionEvent event) {
        String emailInserido = txtEmailUsuario.getText().trim();
        int limite = obterLimiteUsuarios();

        if (limite <= 0) {
            exibirAlerta("Atenção",
                    "Por favor, preencha primeiro a Qtd. de Usuários (aba 1) antes de inserir emails.",
                    Alert.AlertType.WARNING);
            return;
        }

        if (!emailInserido.isEmpty()) {
            if (listaEmailsTemporaria.size() < limite) {
                // Adiciona o e‑mail com o número sequencial correspondente
                listaEmailsTemporaria.add(new EmailItem(listaEmailsTemporaria.size() + 1, emailInserido));
                txtEmailUsuario.clear();
            } else {
                exibirAlerta("Limite Excedido",
                        "Você já cadastrou o número máximo de usuários permitido para este cliente (" + limite + ").",
                        Alert.AlertType.WARNING);
            }
        }
    }

    /**
     * Ação do botão "Importar CSV" – atualmente apenas exibe um aviso de
     * funcionalidade futura.
     */
    @FXML
    private void importarCsv(ActionEvent event) {
        exibirAlerta("Aviso",
                "A funcionalidade de importação de CSV será implementada em uma versão futura.",
                Alert.AlertType.INFORMATION);
    }

    /**
     * Obtém o limite de usuários a partir do campo txtUsuarios. Retorna 0 se
     * estiver vazio ou inválido.
     */
    private int obterLimiteUsuarios() {
        if (txtUsuarios == null || txtUsuarios.getText() == null || txtUsuarios.getText().trim().isEmpty()) {
            return 0;
        }
        try {
            return Integer.parseInt(txtUsuarios.getText().trim());
        } catch (Exception e) {
            return 0;
        }
    }

    // ==========================================
    // VISUALIZAÇÃO E EDIÇÃO
    // ==========================================
    /**
     * Método auxiliar para obter um valor seguro de uma coluna do ResultSet. Se
     * a coluna for nula, retorna "N/A".
     */
    private String getValorSeguro(ResultSet rs, String nomeColuna) {
        try {
            String v = rs.getString(nomeColuna);
            return v != null ? v : "N/A";
        } catch (SQLException e) {
            return "N/A";
        }
    }

    /**
     * Prepara a tela para visualização (somente leitura). Preenche os campos e
     * bloqueia a edição.
     */
    public void carregarDadosParaVisualizacao(ClienteCompartilhado cliente) {
        this.modoVisualizacao = true;
        preencherCamposComuns(cliente);
        bloquearCampos();
    }

    /**
     * Prepara a tela para edição de um cliente compartilhado. Preenche os
     * campos e mantém a edição habilitada.
     */
    public void carregarDadosParaEdicao(ClienteCompartilhado cliente) {
        this.modoEdicao = true;
        this.idClienteEdicao = cliente.getId();
        preencherCamposComuns(cliente);
    }

    /**
     * Desabilita todos os campos de texto, combos e date picker. Usado quando a
     * tela é aberta apenas para visualização.
     */
    private void bloquearCampos() {
        // Campos de texto
        if (txtRazaoSocial != null) {
            txtRazaoSocial.setEditable(false);
        }
        if (txtCpfCnpj != null) {
            txtCpfCnpj.setEditable(false);
        }
        if (txtCodAg != null) {
            txtCodAg.setEditable(false);
        }
        if (txtPastaRede != null) {
            txtPastaRede.setEditable(false);
        }
        if (txtSistemas != null) {
            txtSistemas.setEditable(false);
        }
        if (txtContato != null) {
            txtContato.setEditable(false);
        }
        if (txtTelefone != null) {
            txtTelefone.setEditable(false);
        }
        if (txtUsuarios != null) {
            txtUsuarios.setEditable(false);
        }
        if (txtEmail != null) {
            txtEmail.setEditable(false);
        }
        if (txtRazaoAntiga != null) {
            txtRazaoAntiga.setEditable(false);
        }

        // ComboBoxes
        if (cbSegmento != null) {
            cbSegmento.setDisable(true);
        }
        if (cbTipoNuvem != null) {
            cbTipoNuvem.setDisable(true);
        }
        if (cbStatus != null) {
            cbStatus.setDisable(true);
        }
        if (cbBanco != null) {
            cbBanco.setDisable(true);
        }
        if (cbOrigem != null) {
            cbOrigem.setDisable(true);
        }
        if (cbPod != null) {
            cbPod.setDisable(true);
        }

        // DatePicker
        if (dpDataCriacao != null) {
            dpDataCriacao.setDisable(true);
        }
    }

    /**
     * Preenche os campos da Aba 1 com os dados do objeto ClienteCompartilhado.
     * Consulta também as tabelas auxiliares (bancos e e‑mails) para montar as
     * listas.
     */
    private void preencherCamposComuns(ClienteCompartilhado cliente) {
        if (cliente == null) {
            return;
        }

        // Preenche campos simples – cada bloco dentro de try/catch para não parar se algum falhar
        try {
            if (cbTipoNuvem != null && cliente.getTipoNuvem() != null) {
                cbTipoNuvem.getEditor().setText(cliente.getTipoNuvem());
            }
        } catch (Exception e) {
        }
        try {
            if (cbPod != null) {
                cbPod.getEditor().setText(String.valueOf(cliente.getPod()));
            }
        } catch (Exception e) {
        }
        try {
            if (txtRazaoSocial != null) {
                txtRazaoSocial.setText(cliente.getRazaoSocial() != null ? cliente.getRazaoSocial() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtCpfCnpj != null) {
                txtCpfCnpj.setText(cliente.getCpfCnpj() != null ? cliente.getCpfCnpj() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtCodAg != null) {
                txtCodAg.setText(cliente.getCodAg() != null ? cliente.getCodAg() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtPastaRede != null) {
                txtPastaRede.setText(cliente.getPastaRede() != null ? cliente.getPastaRede() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtSistemas != null) {
                txtSistemas.setText(cliente.getSistemas() != null ? cliente.getSistemas() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (cbStatus != null && cliente.getStatus() != null) {
                cbStatus.getEditor().setText(cliente.getStatus());
            }
        } catch (Exception e) {
        }
        try {
            if (cbBanco != null && cliente.getBancoDados() != null) {
                cbBanco.getEditor().setText(cliente.getBancoDados());
            }
        } catch (Exception e) {
        }
        try {
            if (txtContato != null) {
                txtContato.setText(cliente.getContato() != null ? cliente.getContato() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtTelefone != null) {
                txtTelefone.setText(cliente.getTelefone() != null ? cliente.getTelefone() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (txtEmail != null) {
                txtEmail.setText(cliente.getEmail() != null ? cliente.getEmail() : "");
            }
        } catch (Exception e) {
        }
        try {
            if (cbOrigem != null && cliente.getOrigem() != null) {
                cbOrigem.getEditor().setText(cliente.getOrigem());
            }
        } catch (Exception e) {
        }
        try {
            if (txtUsuarios != null) {
                txtUsuarios.setText(String.valueOf(cliente.getUsuarios()));
            }
        } catch (Exception e) {
        }

        // Converte a data de criação, se disponível
        if (cliente.getDataCriacao() != null && !cliente.getDataCriacao().isEmpty()
                && !cliente.getDataCriacao().equals("N/A") && dpDataCriacao != null) {
            try {
                dpDataCriacao.setValue(LocalDate.parse(cliente.getDataCriacao().split(" ")[0]));
            } catch (Exception e) {
            }
        }

        // Carrega as listas de bancos e e‑mails do banco de dados
        try (Connection conexao = conectar()) {
            // 1. Carrega bancos associados
            try {
                String sqlBanco = "SELECT * FROM bancos_nuvem_compartilhada WHERE id_cliente = ?";
                try (PreparedStatement cmd = conexao.prepareStatement(sqlBanco)) {
                    cmd.setInt(1, cliente.getId());
                    try (ResultSet rs = cmd.executeQuery()) {
                        listaBancosTemporaria.clear();
                        while (rs.next()) {
                            listaBancosTemporaria.add(new BancoItem(
                                    getValorSeguro(rs, "ip_servidor"),
                                    getValorSeguro(rs, "nome_banco"),
                                    getValorSeguro(rs, "caminho_conexao"),
                                    getValorSeguro(rs, "sgbd"),
                                    getValorSeguro(rs, "usuario_banco"),
                                    getValorSeguro(rs, "senha_banco"),
                                    getValorSeguro(rs, "segmento")
                            ));
                        }
                    }
                }
            } catch (SQLException eBanco) {
                System.out.println("Erro ao ler tabela de Bancos: " + eBanco.getMessage());
            }

            // Se a lista de bancos não estiver vazia, usa o segmento do primeiro para preencher o combo
            if (!listaBancosTemporaria.isEmpty() && cbSegmento != null) {
                cbSegmento.getEditor().setText(listaBancosTemporaria.get(0).getSegmento());
            }

            // 2. Carrega e‑mails dos usuários
            try {
                String sqlAcessos = "SELECT email_usuario FROM usuarios_nuvem_compartilhada WHERE id_cliente = ?";
                try (PreparedStatement cmd = conexao.prepareStatement(sqlAcessos)) {
                    cmd.setInt(1, cliente.getId());
                    try (ResultSet rs = cmd.executeQuery()) {
                        int index = 1;
                        listaEmailsTemporaria.clear();
                        while (rs.next()) {
                            listaEmailsTemporaria.add(new EmailItem(index++, getValorSeguro(rs, "email_usuario")));
                        }
                    }
                }
            } catch (SQLException eAcesso) {
                // Se der erro, a lista permanece vazia
            }
        } catch (SQLException e) {
            // Problema de conexão: os campos já preenchidos parcialmente continuam
        }
    }

    // ==========================================
    // PERSISTÊNCIA E VALIDAÇÃO INDIVIDUAL
    // ==========================================
    /**
     * Acionado ao clicar no botão "Salvar". Valida cada campo obrigatório e, se
     * todos preenchidos, persiste no banco. Em modo edição, executa um UPDATE;
     * caso contrário, um INSERT. Utiliza transação para garantir que cliente,
     * bancos e e‑mails sejam gravados (ou revertidos) de forma atômica.
     */
    @FXML
    private void salvarCliente(ActionEvent event) {
        if (modoVisualizacao) {
            fecharJanela();
            return;
        }

        // ---- Validação campo a campo (um alerta específico para cada caso) ----
        if (cbSegmento.getValue() == null || cbSegmento.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o campo Segmento.", Alert.AlertType.WARNING);
            return;
        }
        if (cbTipoNuvem.getValue() == null || cbTipoNuvem.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Tipo de Nuvem.", Alert.AlertType.WARNING);
            return;
        }
        if (dpDataCriacao.getValue() == null) {
            exibirAlerta("Aviso", "Preencha a Data de Criação.", Alert.AlertType.WARNING);
            return;
        }
        if (cbPod.getValue() == null || cbPod.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o POD.", Alert.AlertType.WARNING);
            return;
        }
        if (txtRazaoSocial.getText() == null || txtRazaoSocial.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha a Razão Social.", Alert.AlertType.WARNING);
            return;
        }
        if (txtCpfCnpj.getText() == null || txtCpfCnpj.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o CPF/CNPJ.", Alert.AlertType.WARNING);
            return;
        }
        if (txtCodAg.getText() == null || txtCodAg.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Código AG.", Alert.AlertType.WARNING);
            return;
        }
        if (txtPastaRede.getText() == null || txtPastaRede.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha a Pasta de Rede.", Alert.AlertType.WARNING);
            return;
        }
        if (txtSistemas.getText() == null || txtSistemas.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha os Sistemas.", Alert.AlertType.WARNING);
            return;
        }
        if (cbStatus.getValue() == null || cbStatus.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Status.", Alert.AlertType.WARNING);
            return;
        }
        if (cbBanco.getValue() == null || cbBanco.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Tipo de Base (Banco).", Alert.AlertType.WARNING);
            return;
        }
        if (txtContato.getText() == null || txtContato.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Contato Responsável.", Alert.AlertType.WARNING);
            return;
        }
        if (txtTelefone.getText() == null || txtTelefone.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o Telefone.", Alert.AlertType.WARNING);
            return;
        }
        if (cbOrigem.getValue() == null || cbOrigem.getValue().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha a Origem.", Alert.AlertType.WARNING);
            return;
        }
        if (txtUsuarios.getText() == null || txtUsuarios.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha a Qtd. de Usuários.", Alert.AlertType.WARNING);
            return;
        }
        if (txtEmail.getText() == null || txtEmail.getText().trim().isEmpty()) {
            exibirAlerta("Aviso", "Preencha o E-mail.", Alert.AlertType.WARNING);
            return;
        }

        // Validações numéricas
        int pod = 0, usuarios = 0;
        try {
            pod = Integer.parseInt(cbPod.getValue().trim());
        } catch (Exception e) {
            exibirAlerta("Erro", "P.O.D deve ser numérico.", Alert.AlertType.ERROR);
            return;
        }
        try {
            usuarios = Integer.parseInt(txtUsuarios.getText().trim());
        } catch (Exception e) {
            exibirAlerta("Erro", "Qtd. Usuários deve ser numérica.", Alert.AlertType.ERROR);
            return;
        }

        // Define se é INSERT (com RETURNING id) ou UPDATE
        String sqlCliente = modoEdicao
                ? "UPDATE clientes_compartilhados SET tipo_nuvem=?, pod=?, data_criacao=?, razao_social=?, cpf_cnpj=?, razao_cnpj_antigos=?, cod_ag=?, pasta_rede=?, contato=?, usuarios=?, origem=?, telefone=?, email=?, sistemas=?, status=?, banco=? WHERE id=?"
                : "INSERT INTO clientes_compartilhados (tipo_nuvem, pod, data_criacao, razao_social, cpf_cnpj, razao_cnpj_antigos, cod_ag, pasta_rede, contato, usuarios, origem, telefone, email, sistemas, status, banco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id";

        try (Connection conexao = conectar()) {
            conexao.setAutoCommit(false);  // Inicia transação manual
            try {
                int idClienteAplicado = modoEdicao ? idClienteEdicao : -1;

                // 1. Insere ou atualiza o cliente
                try (PreparedStatement cmdCliente = conexao.prepareStatement(sqlCliente,
                        modoEdicao ? java.sql.Statement.NO_GENERATED_KEYS : java.sql.Statement.RETURN_GENERATED_KEYS)) {

                    cmdCliente.setString(1, cbTipoNuvem.getValue().trim());
                    cmdCliente.setInt(2, pod);
                    cmdCliente.setDate(3, java.sql.Date.valueOf(dpDataCriacao.getValue()));
                    cmdCliente.setString(4, txtRazaoSocial.getText().trim());
                    cmdCliente.setString(5, txtCpfCnpj.getText().trim());
                    cmdCliente.setString(6, txtRazaoAntiga.getText() != null ? txtRazaoAntiga.getText().trim() : "");
                    cmdCliente.setString(7, txtCodAg.getText().trim());
                    cmdCliente.setString(8, txtPastaRede.getText().trim());
                    cmdCliente.setString(9, txtContato.getText().trim());
                    cmdCliente.setInt(10, usuarios);
                    cmdCliente.setString(11, cbOrigem.getValue().trim());
                    cmdCliente.setString(12, txtTelefone.getText().trim());
                    cmdCliente.setString(13, txtEmail.getText().trim());
                    cmdCliente.setString(14, txtSistemas.getText().trim());
                    cmdCliente.setString(15, cbStatus.getValue().trim());
                    cmdCliente.setString(16, cbBanco.getValue().trim());

                    if (modoEdicao) {
                        cmdCliente.setInt(17, idClienteEdicao);
                        cmdCliente.executeUpdate();
                    } else {
                        cmdCliente.executeUpdate();
                        // Recupera o ID gerado pelo RETURNING id
                        try (ResultSet chaves = cmdCliente.getGeneratedKeys()) {
                            if (chaves.next()) {
                                idClienteAplicado = chaves.getInt(1);
                            }
                        }
                    }
                }

                if (idClienteAplicado == -1) {
                    throw new SQLException("ID do Cliente não obtido.");
                }

                // Se estiver editando, remove os registros antigos das tabelas auxiliares
                if (modoEdicao) {
                    try (PreparedStatement cmdDelB = conexao.prepareStatement(
                            "DELETE FROM bancos_nuvem_compartilhada WHERE id_cliente = ?")) {
                        cmdDelB.setInt(1, idClienteAplicado);
                        cmdDelB.executeUpdate();
                    }
                    try (PreparedStatement cmdDelA = conexao.prepareStatement(
                            "DELETE FROM usuarios_nuvem_compartilhada WHERE id_cliente = ?")) {
                        cmdDelA.setInt(1, idClienteAplicado);
                        cmdDelA.executeUpdate();
                    }
                }

                // 2. Insere os bancos (em lote)
                if (!listaBancosTemporaria.isEmpty()) {
                    String sqlBancoQ = "INSERT INTO bancos_nuvem_compartilhada (id_cliente, segmento, razao_social, ip_servidor, nome_banco, caminho_conexao, caminho_banco, sgbd, usuario_banco, senha_banco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement cmdBanco = conexao.prepareStatement(sqlBancoQ)) {
                        for (BancoItem b : listaBancosTemporaria) {
                            cmdBanco.setInt(1, idClienteAplicado);
                            cmdBanco.setString(2, b.getSegmento());
                            cmdBanco.setString(3, txtRazaoSocial.getText().trim());
                            cmdBanco.setString(4, b.getServidor());
                            cmdBanco.setString(5, b.getNome());
                            cmdBanco.setString(6, b.getConexao());
                            cmdBanco.setString(7, b.getConexao()); // caminho_banco usa o mesmo valor
                            cmdBanco.setString(8, b.getSgbd());
                            cmdBanco.setString(9, b.getUsuario());
                            cmdBanco.setString(10, b.getSenha());
                            cmdBanco.addBatch();  // Adiciona ao lote
                        }
                        cmdBanco.executeBatch(); // Executa todas de uma vez
                    }
                }

                // 3. Insere os e‑mails (em lote)
                if (!listaEmailsTemporaria.isEmpty()) {
                    try (PreparedStatement cmdAcesso = conexao.prepareStatement(
                            "INSERT INTO usuarios_nuvem_compartilhada (id_cliente, email_usuario) VALUES (?, ?)")) {
                        for (EmailItem item : listaEmailsTemporaria) {
                            cmdAcesso.setInt(1, idClienteAplicado);
                            cmdAcesso.setString(2, item.getEmail());
                            cmdAcesso.addBatch();
                        }
                        cmdAcesso.executeBatch();
                    }
                }

                conexao.commit();  // Confirma a transação
                exibirAlerta("Sucesso", modoEdicao ? "Cliente atualizado!" : "Gravado com êxito!", Alert.AlertType.INFORMATION);

                // Registro simples no console (poderia ser integrado a um logger de auditoria)
                String acaoLog = modoEdicao ? "EDIÇÃO" : "INCLUSÃO";
                LoggerAuditoria.registrar(acaoLog, "O cliente compartilhado " + txtRazaoSocial.getText().trim() + " (ID: " + idClienteAplicado + ") foi " + (modoEdicao ? "alterado." : "criado."));
                fecharJanela();

            } catch (SQLException e) {
                conexao.rollback();  // Desfaz qualquer alteração em caso de erro
                throw e;
            } finally {
                conexao.setAutoCommit(true); // Restaura o modo automático
            }
        } catch (SQLException e) {
            exibirAlerta("Erro", "Falha DB: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    /**
     * Botão Cancelar: apenas fecha a janela.
     */
    @FXML
    private void cancelar(ActionEvent event) {
        fecharJanela();
    }

    /**
     * Fecha a janela atual.
     */
    private void fecharJanela() {
        ((Stage) txtRazaoSocial.getScene().getWindow()).close();
    }

    /**
     * Exibe uma mensagem de alerta.
     */
    private void exibirAlerta(String t, String m, Alert.AlertType tipo) {
        Alert a = new Alert(tipo);
        a.setTitle(t);
        a.setHeaderText(null);
        a.setContentText(m);
        a.showAndWait();
    }

    // ==================== CLASSES INTERNAS PARA AS TABELAS ====================
    /**
     * Representa um e‑mail de usuário na tabela da Aba 2.
     */
    public static class EmailItem {

        private final SimpleIntegerProperty numero;  // Número sequencial
        private final SimpleStringProperty email;    // Endereço de e‑mail

        public EmailItem(int n, String e) {
            this.numero = new SimpleIntegerProperty(n);
            this.email = new SimpleStringProperty(e);
        }

        public SimpleIntegerProperty numeroProperty() {
            return numero;
        }

        public SimpleStringProperty emailProperty() {
            return email;
        }

        public String getEmail() {
            return email.get();
        }
    }

    /**
     * Representa um banco de dados associado ao cliente (Aba 3).
     */
    public static class BancoItem {

        private final SimpleStringProperty servidor;
        private final SimpleStringProperty nome;
        private final SimpleStringProperty conexao;
        private final SimpleStringProperty sgbd;
        private final SimpleStringProperty usuario;
        private final SimpleStringProperty senha;
        private final SimpleStringProperty segmento;  // Segmento informado no cadastro do banco

        public BancoItem(String s, String n, String c, String sg, String u, String se, String seg) {
            this.servidor = new SimpleStringProperty(s);
            this.nome = new SimpleStringProperty(n);
            this.conexao = new SimpleStringProperty(c);
            this.sgbd = new SimpleStringProperty(sg);
            this.usuario = new SimpleStringProperty(u);
            this.senha = new SimpleStringProperty(se);
            this.segmento = new SimpleStringProperty(seg);
        }

        // Getters comuns
        public String getServidor() {
            return servidor.get();
        }

        public String getNome() {
            return nome.get();
        }

        public String getConexao() {
            return conexao.get();
        }

        public String getSgbd() {
            return sgbd.get();
        }

        public String getUsuario() {
            return usuario.get();
        }

        public String getSenha() {
            return senha.get();
        }

        public String getSegmento() {
            return segmento.get();
        }

        // Propriedades observáveis (necessárias para a TableView)
        public SimpleStringProperty servidorProperty() {
            return servidor;
        }

        public SimpleStringProperty nomeProperty() {
            return nome;
        }

        public SimpleStringProperty conexaoProperty() {
            return conexao;
        }

        public SimpleStringProperty sgbdProperty() {
            return sgbd;
        }

        public SimpleStringProperty usuarioProperty() {
            return usuario;
        }

        public SimpleStringProperty senhaProperty() {
            return senha;
        }
    }
}
