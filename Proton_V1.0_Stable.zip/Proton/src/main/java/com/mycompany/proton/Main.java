package com.mycompany.proton;
/**
 *
 * @author gabriellevi_forteste
 */
public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}
