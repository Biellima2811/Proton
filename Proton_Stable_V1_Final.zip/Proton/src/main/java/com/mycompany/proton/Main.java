package com.mycompany.proton;
/**
 *
 * @author gabriellevi_forteste
 */
public class Main {
    public static void main(String[] args) {
        // 1. INICIA O GERADOR DE LOGS ANTES DE QUALQUER OUTRA COISA
        GerenciadorDeLog.iniciar();
        App.main(args);
    }
}
