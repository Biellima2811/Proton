package com.mycompany.proton;

import org.mindrot.jbcrypt.BCrypt;

public class Seguranca {

    // Gera um hash seguro para uma senha em texto puro
    public static String hashSenha(String senhaPura) {
        return BCrypt.hashpw(senhaPura, BCrypt.gensalt(12)); // O fator 12 é o custo computacional, muito seguro
    }

    // Verifica se a senha digitada pelo usuário confere com o hash salvo no banco
    public static boolean verificarSenha(String senhaPura, String hashSalvo) {
        try {
            return BCrypt.checkpw(senhaPura, hashSalvo);
        } catch (Exception e) {
            return false;
        }
    }
}