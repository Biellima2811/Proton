package com.mycompany.proton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author gabriellevi_forteste
 */
public class FormClienteCompartilhadoController implements Initializable {

    // --- ABA 1: DADOS GERAIS ---
    @FXML
    private ComboBox<String> cbSegmento;
    @FXML
    private ComboBox<String> cbTipoNuvem;
    @FXML
    private DatePicker dpDataCriacao;
    @FXML
    private ComboBox<String> cbPod;
    @FXML
    private TextField txtRazaoSocial;
    @FXML
    private TextField txtCpfCnpj;
    @FXML
    private TextField txtCodAg;
    @FXML
    private TextField txtPastaRede;
    @FXML
    private TextField txtSistemas;
    @FXML
    private ComboBox<String> cbStatus;
    @FXML
    private ComboBox<String> cbBanco;
    @FXML
    private TextField txtContato;
    @FXML
    private TextField txtTelefone;
    @FXML
    private ComboBox<String> cbOrigem;
    @FXML
    private TextField txtUsuarios;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtRazaoAntiga;

    // --- ABA 2: CADASTRO DE EMAILS ---
    @FXML
    private TextField txtEmailUsuario;
    @FXML
    private TableView<EmailItem> tabelaEmails;
    @FXML
    private TableColumn<EmailItem, Integer> colUserNum;
    @FXML
    private TableColumn<EmailItem, String> colUserEmail;
    private ObservableList<EmailItem> listaEmailsTemporaria = FXCollections.observableArrayList();

    // --- ABA 3: DADOS DE BANCO DE DADOS ---
    @FXML
    private TextField txtDbServidor;
    @FXML
    private TextField txtDbNome;
    @FXML
    private TextField txtDbConexao;
    @FXML
    private ComboBox<String> cbDbSgbd;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicialização as listas suspensas (ComboBoxes)
        cbSegmento.setItems(FXCollections.observableArrayList("Contábil", "Corporativo"));
        cbTipoNuvem.setItems(FXCollections.observableArrayList("Compartilhada", "Dedicada"));
        cbStatus.setItems(FXCollections.observableArrayList("Ativo", "Ativando", "Desativado", "Pendente"));
        cbBanco.setItems(FXCollections.observableArrayList("SQL", "Firebird"));
        cbOrigem.setItems(FXCollections.observableArrayList("Novo", "Base", "Novo Esocial"));
        cbPod.setItems(FXCollections.observableArrayList("1", "2", "3", "4", "5", "6", "7", "8"));
        cbDbSgbd.setItems(FXCollections.observableArrayList("Firebird", "MSSQL"));

        // Mapeia as colunas da tabela de e-mails de acesso
        colUserNum.setCellValueFactory(cellData -> cellData.getValue().numeroProperty().asObject());
        colUserEmail.setCellValueFactory(cellData -> cellData.getValue().emailProperty());
        tabelaEmails.setItems(listaEmailsTemporaria);
    }

    @FXML
    private void inserirEmail(ActionEvent event) {
        String emailInserido = txtEmailUsuario.getText().trim();

        if (emailInserido.isEmpty()) {
            exibirAlerta("Campo Vazio!", "Por favor, digite um e-mail válido antes de inserir.", Alert.AlertType.WARNING);
            return;
        }

        // CORREÇÃO: Chama o método para descobrir o limite antes de validar
        int limiteMaximo = obterLimiteUsuarios();

        if (limiteMaximo <= 0) {
            return;
        }

        // Executa a trava logica de limite de linhas
        if (listaEmailsTemporaria.size() >= limiteMaximo) {
            exibirAlerta("Limite Atingido!", "Não é possível adicionar mais e-mails. O limite de " + limiteMaximo + " usuários foi atingido!", Alert.AlertType.ERROR);
            return;
        }

        // Adiciona à lista da tabela incrementando o índice visual
        int proximoIndice = listaEmailsTemporaria.size() + 1;
        listaEmailsTemporaria.add(new EmailItem(proximoIndice, emailInserido));
        txtEmailUsuario.clear();
    }

    @FXML
    private void importarCsv(ActionEvent event) {
        // CORREÇÃO: Erro de digitação na chamada do método corrigido
        int limiteMaximo = obterLimiteUsuarios();
        if (limiteMaximo <= 0) {
            return;
        }

        // CORREÇÃO: Faltava instanciar a classe com ()
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecione arquivo de e-mails (CSV ou TXT)");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Arquivos de Texto", "*.csv", "*.txt"));
        Stage palco = (Stage) tabelaEmails.getScene().getWindow();
        File arquivo = fileChooser.showOpenDialog(palco);

        if (arquivo != null) {
            try (BufferedReader leitor = new BufferedReader(new FileReader(arquivo))) {
                String linha;
                while ((linha = leitor.readLine()) != null) {
                    String emailLimpo = linha.trim();
                    if (!emailLimpo.isEmpty() && emailLimpo.contains("@")) {
                        // Trava dinamicamente durante a leitura do arquivo se estourar o limite do campo
                        if (listaEmailsTemporaria.size() >= limiteMaximo) {
                            exibirAlerta("Importação Parcial", "O arquivo continha mais e-mails do que o permitido. Foram importados apenas os primeiros " + limiteMaximo + " registros.", Alert.AlertType.WARNING);
                            return;
                        }
                        int proximoIndice = listaEmailsTemporaria.size() + 1;
                        listaEmailsTemporaria.add(new EmailItem(proximoIndice, emailLimpo));
                    }
                }
                exibirAlerta("Sucesso", "E-mails importados do arquivo com sucesso!", Alert.AlertType.INFORMATION);
            } catch (IOException e) {
                exibirAlerta("Erro de Arquivo", "Não foi possível ler o arquivo selecionado: " + e.getMessage(), Alert.AlertType.ERROR);
            }
        }
    }

    private int obterLimiteUsuarios() {
        String textoUsuarios = txtUsuarios.getText().trim();
        if (textoUsuarios.isEmpty()) {
            exibirAlerta("Falta Quantidade", "Por favor, defina a 'Qtd. Usuários' na aba anterior para liberar as inserções.", Alert.AlertType.WARNING);
            return 0;
        }
        try {
            return Integer.parseInt(textoUsuarios);
        } catch (NumberFormatException e) {
            exibirAlerta("Valor Inválido", "O campo 'Qtd. Usuários' deve conter um número inteiro válido.", Alert.AlertType.ERROR);
            return 0;
        }
    }

    @FXML
    private void salvarCliente(ActionEvent event) {
        String razao = txtRazaoSocial.getText();
        String ipServidor = txtDbServidor != null ? txtDbServidor.getText() : "";
        String nomeDB = txtDbNome != null ? txtDbNome.getText() : "";
        String caminhoDB = txtDbConexao != null ? txtDbConexao.getText() : "";

        if (razao == null || razao.trim().isEmpty()) {
            exibirAlerta("Atenção", "A Razão Social é obrigatória!", Alert.AlertType.WARNING);
            return;
        }

        if (ipServidor.trim().isEmpty() || nomeDB.trim().isEmpty() || caminhoDB.trim().isEmpty()) {
            exibirAlerta("Atenção", "Preencha todos os dados do banco de dados na aba Dados de DataBase!", Alert.AlertType.WARNING);
            return;
        }

        int pod = 0;
        int usuarios = 0;

        try {
            if (cbPod.getValue() != null && !cbPod.getValue().isEmpty()) {
                pod = Integer.parseInt(cbPod.getValue());
            }
            if (txtUsuarios.getText() != null && !txtUsuarios.getText().isEmpty()) {
                usuarios = Integer.parseInt(txtUsuarios.getText());
            }
        } catch (NumberFormatException e) {
            exibirAlerta("Erro", "Campos numéricos preenchidos de forma inválida.", Alert.AlertType.ERROR);
            return;
        }

        LocalDate dataLocal = dpDataCriacao.getValue();
        java.sql.Date dataCriacaoSql = (dataLocal != null) ? java.sql.Date.valueOf(dataLocal) : null;

        String sql = "INSERT INTO clientes_compartilhados (tipo_nuvem, pod, data_criacao, razao_social, cpf_cnpj, razao_cnpj_antigos, cod_ag, pasta_rede, contato, usuarios, origem, telefone, email, sistemas, status, banco) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = conectar(); PreparedStatement comando = conexao.prepareStatement(sql)) {

            comando.setString(1, cbTipoNuvem.getValue());
            comando.setInt(2, pod);
            comando.setDate(3, dataCriacaoSql);
            comando.setString(4, razao);
            comando.setString(5, txtCpfCnpj.getText());
            comando.setString(6, txtRazaoAntiga.getText());
            comando.setString(7, txtCodAg.getText());
            comando.setString(8, txtPastaRede.getText());
            comando.setString(9, txtContato.getText());
            comando.setInt(10, usuarios);
            comando.setString(11, cbOrigem.getValue());
            comando.setString(12, txtTelefone.getText());
            comando.setString(13, txtEmail.getText());
            comando.setString(14, txtSistemas.getText());
            comando.setString(15, cbStatus.getValue());
            comando.setString(16, cbBanco.getValue());

            comando.executeUpdate();

            exibirAlerta("Sucesso", "Cliente Compartilhado gravado com êxito!", Alert.AlertType.INFORMATION);
            fecharJanela();
        } catch (SQLException e) {
            exibirAlerta("Erro de Persistência", "Erro ao gravar no PostgreSQL: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private Connection conectar() throws SQLException {
        String ipAplicacao = ConfigBancoController.getIpServidor();
        String urlConexao = String.format("jdbc:postgresql://%s:5432/proton", ipAplicacao);
        return DriverManager.getConnection(urlConexao, "postgres", "tec@123");
    }

    @FXML
    private void cancelar(ActionEvent event) {
        fecharJanela();
    }

    private void fecharJanela() {
        ((Stage) txtRazaoSocial.getScene().getWindow()).close();
    }

    private void exibirAlerta(String titulo, String mensagem, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    // Classe interna para preencher a tabela de e-mails dinamicamente
    public static class EmailItem {

        private final SimpleIntegerProperty numero;
        private final SimpleStringProperty email;

        public EmailItem(int numero, String email) {
            this.numero = new SimpleIntegerProperty(numero);
            this.email = new SimpleStringProperty(email);
        }

        public SimpleIntegerProperty numeroProperty() {
            return numero;
        }

        public SimpleStringProperty emailProperty() {
            return email;
        }

        public int getNumero() {
            return numero.get();
        }

        public String getEmail() {
            return email.get();
        }
    }
}
