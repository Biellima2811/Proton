package com.mycompany.proton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ConfigBancoController {
    
    // VARIÁVEIS GLOBAIS (static) DA APLICAÇÃO
    private static String ipServidor = "localhost";
    private static String nomeBanco = "proton";
    private static String usuario = "postgres";
    private static String senha = "tec@123";
    
    // MÉTODO PÚBLICO PARA OUTRAS CLASSES PEGAREM O IP
    public static String getIpServidor() {
        return ipServidor;
    }

    @FXML
    private void salvarConfiguracao(ActionEvent event){
        String urlConexao = "jdbc:postgresql://" + ipServidor + ":5432/" + nomeBanco;
        
        try(Connection conexao = DriverManager.getConnection(urlConexao, usuario, senha)){
            System.out.println("Sucesso!, Conectado ao SGBD PostgreSQL no IP: " + ipServidor);
            try {
                App.iniciarPainelPrincipal();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            System.out.printf("ERRO de PostgreSQL: %s", e.getMessage());
        }
    }
}