package com.mycompany.proton;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class PrimaryController implements Initializable {

    @FXML
    private Label lblTituloAba;
    @FXML
    private Button btnDedicados;
    @FXML
    private Button btnCompartilhados;
    @FXML
    private TextField txtPesquisa; // <-- O Campo de Pesquisa aqui!

    // --- ELEMENTOS DA TABELA DE DEDICADOS ---
    @FXML
    private TableView<Cliente> tabelaDedicados;
    @FXML
    private TableColumn<Cliente, Integer> colId;
    @FXML
    private TableColumn<Cliente, String> colNome;
    @FXML
    private TableColumn<Cliente, String> colCnpj;
    @FXML
    private TableColumn<Cliente, Integer> colQntServer;
    @FXML
    private TableColumn<Cliente, String> colAd;
    @FXML
    private TableColumn<Cliente, String> colAmbiente;
    @FXML
    private TableColumn<Cliente, Boolean> colVpn;
    @FXML
    private TableColumn<Cliente, String> colSgbd;

    // --- ELEMENTOS DA TABELA DE COMPARTILHADOS ---
    @FXML
    private TableView<ClienteCompartilhado> tabelaCompartilhados;
    @FXML
    private TableColumn<ClienteCompartilhado, Integer> colCId;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCTipoNuvem;
    @FXML
    private TableColumn<ClienteCompartilhado, Integer> colCPod;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCData;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCRazao;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCCnpj;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCAg;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCPasta;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCContato;
    @FXML
    private TableColumn<ClienteCompartilhado, Integer> colCUsuarios;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCSistemas;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCStatus;
    @FXML
    private TableColumn<ClienteCompartilhado, String> colCBanco;

    // Listas baseadas no banco de dados
    private ObservableList<Cliente> listaDedicados = FXCollections.observableArrayList();
    private ObservableList<ClienteCompartilhado> listaCompartilhados = FXCollections.observableArrayList();
    
    //Guarda a aba ativa. (1 = Dedicados, 2 = Compartilhados)
    private int abaAtiva = 1;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Mapeamento Dedicados
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        colCnpj.setCellValueFactory(new PropertyValueFactory<>("cnpj"));
        colQntServer.setCellValueFactory(new PropertyValueFactory<>("qnt_server"));
        colAd.setCellValueFactory(new PropertyValueFactory<>("active_directory"));
        colAmbiente.setCellValueFactory(new PropertyValueFactory<>("ambiente"));
        colVpn.setCellValueFactory(new PropertyValueFactory<>("vpn"));
        colSgbd.setCellValueFactory(new PropertyValueFactory<>("sgbd"));

        // Mapeamento Compartilhados
        colCId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colCTipoNuvem.setCellValueFactory(new PropertyValueFactory<>("tipoNuvem"));
        colCPod.setCellValueFactory(new PropertyValueFactory<>("pod"));
        colCData.setCellValueFactory(new PropertyValueFactory<>("dataCriacao"));
        colCRazao.setCellValueFactory(new PropertyValueFactory<>("razaoSocial"));
        colCCnpj.setCellValueFactory(new PropertyValueFactory<>("cpfCnpj"));
        colCAg.setCellValueFactory(new PropertyValueFactory<>("codAg"));
        colCPasta.setCellValueFactory(new PropertyValueFactory<>("pastaRede"));
        colCContato.setCellValueFactory(new PropertyValueFactory<>("contato"));
        colCUsuarios.setCellValueFactory(new PropertyValueFactory<>("usuarios"));
        colCSistemas.setCellValueFactory(new PropertyValueFactory<>("sistemas"));
        colCStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        colCBanco.setCellValueFactory(new PropertyValueFactory<>("bancoDados"));

        // 1. CARREGA OS DADOS INICIAIS DO BANCO
        carregarDadosDedicados();
        carregarDadosCompartilhados();

        // 2. ATIVA A MAGIA DA PESQUISA DINÂMICA
        configurarFiltroPesquisa();
    }

    private void configurarFiltroPesquisa() {
        FilteredList<Cliente> filtroDedicados = new FilteredList<>(listaDedicados, b -> true);
        FilteredList<ClienteCompartilhado> filtroCompartilhados = new FilteredList<>(listaCompartilhados, b -> true);

        txtPesquisa.textProperty().addListener((observable, oldValue, newValue) -> {
            
            // 1. Pega o texto e deixa minúsculo
            String filtroTexto = (newValue == null) ? "" : newValue.toLowerCase();
            
            // 2. REGEX: Cria uma versão do filtro SÓ COM NÚMEROS (Remove pontos, barras e traços)
            String filtroNumeros = filtroTexto.replaceAll("[^0-9]", "");

            // --- REGRA DA TABELA DEDICADOS ---
            filtroDedicados.setPredicate(cliente -> {
                if (filtroTexto.isEmpty()) return true;

                // Trava anti-nulo para o Nome
                if (cliente.getNome() != null && cliente.getNome().toLowerCase().contains(filtroTexto)) {
                    return true;
                }
                // Busca de CNPJ (Compara apenas os números puros)
                if (cliente.getCnpj() != null) {
                    String cnpjLimpo = cliente.getCnpj().replaceAll("[^0-9]", "");
                    if (!filtroNumeros.isEmpty() && cnpjLimpo.contains(filtroNumeros)) return true;
                }
                return false;
            });

            // --- REGRA DA TABELA COMPARTILHADOS ---
            filtroCompartilhados.setPredicate(clienteC -> {
                if (filtroTexto.isEmpty()) return true;

                // Trava anti-nulo para a Razão Social (Isso resolve o travamento da sua aba!)
                if (clienteC.getRazaoSocial() != null && clienteC.getRazaoSocial().toLowerCase().contains(filtroTexto)) {
                    return true;
                }
                
                // BÔNUS: Permite pesquisar pelo nome do Contato da empresa também!
                if (clienteC.getContato() != null && clienteC.getContato().toLowerCase().contains(filtroTexto)) {
                    return true;
                }

                // Busca de CNPJ/CPF (Compara apenas os números puros)
                if (clienteC.getCpfCnpj() != null) {
                    String cnpjLimpo = clienteC.getCpfCnpj().replaceAll("[^0-9]", "");
                    if (!filtroNumeros.isEmpty() && cnpjLimpo.contains(filtroNumeros)) return true;
                }
                return false;
            });
        });

        // Ordena e joga nas tabelas definitivamente
        SortedList<Cliente> dedicadosOrdenados = new SortedList<>(filtroDedicados);
        dedicadosOrdenados.comparatorProperty().bind(tabelaDedicados.comparatorProperty());
        tabelaDedicados.setItems(dedicadosOrdenados);

        SortedList<ClienteCompartilhado> compartilhadosOrdenados = new SortedList<>(filtroCompartilhados);
        compartilhadosOrdenados.comparatorProperty().bind(tabelaCompartilhados.comparatorProperty());
        tabelaCompartilhados.setItems(compartilhadosOrdenados);
    }

    // --- LÓGICA DOS BOTÕES ---
    @FXML
    private void abaClientesDedicados(ActionEvent event) {
        abaAtiva = 1; // <--- Seta a memória para Dedicado
        lblTituloAba.setText("Clientes Dedicados");
        btnDedicados.setStyle("-fx-background-color: #3b4248; -fx-text-fill: white; -fx-alignment: center-left; -fx-border-color: #0d6efd; -fx-border-width: 0 0 0 4;");
        btnCompartilhados.setStyle("-fx-background-color: transparent; -fx-text-fill: #adb5bd; -fx-alignment: center-left;");
        tabelaCompartilhados.setVisible(false);
        tabelaDedicados.setVisible(true);
        txtPesquisa.clear(); // Limpa a barra de pesquisa ao trocar de aba
    }

    @FXML
    private void abaClientesCompartilhados(ActionEvent event) {
        abaAtiva = 2; // <--- Seta a memória para Compartilhados
        lblTituloAba.setText("Clientes Compartilhados");
        btnCompartilhados.setStyle("-fx-background-color: #3b4248; -fx-text-fill: white; -fx-alignment: center-left; -fx-border-color: #0d6efd; -fx-border-width: 0 0 0 4;");
        btnDedicados.setStyle("-fx-background-color: transparent; -fx-text-fill: #adb5bd; -fx-alignment: center-left;");
        tabelaDedicados.setVisible(false);
        tabelaCompartilhados.setVisible(true);
        txtPesquisa.clear(); // Limpa a barra de pesquisa ao trocar de aba
    }

    // --- MÉTODOS DE BANCO DE DADOS ---
    private Connection conectar() throws SQLException {
        String ipServidor = "localhost";
        String nomeBanco = "proton";
        String usuario = "postgres";
        String senha = "tec@123"; // COLOQUE SUA SENHA AQUI
        String urlConexao = "jdbc:postgresql://" + ipServidor + ":5432/" + nomeBanco;
        return DriverManager.getConnection(urlConexao, usuario, senha);
    }

    private void carregarDadosDedicados() {
        listaDedicados.clear(); 
        String sql = "SELECT * FROM clientes_dedicados ORDER BY id ASC";
        try (Connection conexao = conectar(); PreparedStatement comando = conexao.prepareStatement(sql); ResultSet resultado = comando.executeQuery()) {
            while (resultado.next()) {
                // Aqui estão os Nomes exatos das novas colunas do PostgreSQL
                listaDedicados.add(new Cliente(
                        resultado.getInt("id"), 
                        resultado.getString("cliente"), 
                        resultado.getString("cnpj_cpf"),
                        resultado.getInt("qnt_de_servs"), 
                        resultado.getString("ad"),
                        resultado.getString("ambiente"), 
                        resultado.getBoolean("vpn"), 
                        resultado.getString("sgbd")
                ));
            }
        } catch (SQLException e) { System.out.println("Erro Dedicados: " + e.getMessage()); }
    }
    
    private void carregarDadosCompartilhados() {
        listaCompartilhados.clear(); 
        String sql = "SELECT * FROM clientes_compartilhados ORDER BY id ASC";
        try (Connection conexao = conectar(); PreparedStatement comando = conexao.prepareStatement(sql); ResultSet resultado = comando.executeQuery()) {
            while (resultado.next()) {
                // Aqui estão os Nomes exatos das novas colunas do PostgreSQL
                listaCompartilhados.add(new ClienteCompartilhado(
                    resultado.getInt("id"), 
                    resultado.getString("tipo_nuvem"), 
                    resultado.getInt("pod"),
                    resultado.getString("data_criacao"), 
                    resultado.getString("razao_social"),
                    resultado.getString("cpf_cnpj"), 
                    resultado.getString("razao_cnpj_antigos"),
                    resultado.getString("cod_ag"), 
                    resultado.getString("pasta_rede"),
                    resultado.getString("contato"), 
                    resultado.getInt("usuarios"),
                    resultado.getString("origem"), 
                    resultado.getString("telefone"),
                    resultado.getString("email"), 
                    resultado.getString("sistemas"),
                    resultado.getString("status"), 
                    resultado.getString("banco")
                ));
            }
        } catch (SQLException e) { System.out.println("Erro Compartilhados: " + e.getMessage()); }
    }
    
    @FXML
    private void abrirModalNovoCliente(ActionEvent event){
        try {
            // Carrega o arquivo FXML do formulário
            javafx.fxml.FXMLLoader fxmlLoader;
            javafx.stage.Stage stage = new javafx.stage.Stage();
            
            // O IF DA INTELIGÊNCIA: Escolhe o arquivo FXML dependendo da aba
            if (abaAtiva == 1) {
                // Está na aba de DEDICADOS
                fxmlLoader = new javafx.fxml.FXMLLoader(getClass().getResource("FormCliente.fxml"));
                stage.setTitle("Novo Cliente Dedicado");
            } else {
                // Está na aba de COMPARTILHADOS (Ainda vamos criar este arquivo)
                fxmlLoader = new javafx.fxml.FXMLLoader(getClass().getResource("FormClienteCompartilhado.fxml"));
                stage.setTitle("Novo Cliente Compartilhado");
            }
            
            javafx.scene.Parent root = fxmlLoader.load();
            stage.setScene(new javafx.scene.Scene(root));
            stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            
            // Abre o pop-up e espera ser fechado!
            stage.showAndWait();
            
            // Quando fechar, recarrega a tabela correta!
            if (abaAtiva == 1) {
                carregarDadosDedicados();
            } else {
                carregarDadosCompartilhados();
            }
        } catch (Exception e) {
            System.out.println("Erro ao abrir a tela de cadastro: " + e.getMessage());
        }
    }
}
