/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proton;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author gabriellevi_forteste
 */
public class FormClienteController implements Initializable {

    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtCnpj;
    @FXML
    private ComboBox<String> cbActDire;
    @FXML
    private TextField txtQntServer;
    @FXML
    private ComboBox<String> cbAmbiente;
    @FXML
    private ComboBox<String> cbSgbd;
    @FXML
    private CheckBox chkVpn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Preenche as opções do seu novo ComboBox de AD
        cbActDire.setItems(FXCollections.observableArrayList("Fortes Tecnologia", "Autos.Sky"));

        // Preenche as opções dos outros Comboxes
        cbAmbiente.setItems(FXCollections.observableArrayList("Micro", "Scaling"));
        cbSgbd.setItems(FXCollections.observableArrayList("SQL", "Firebird"));
    }

    @FXML
    private void salvarCliente(ActionEvent event) {
        // 1° - Pegar os dados da tela
        String nome = txtNome.getText();
        String cnpj = txtCnpj.getText();
        String ActDire = cbActDire.getValue();
        String qntServerStr = txtQntServer.getText();
        String ambiente = cbAmbiente.getValue();
        String sgbd = cbSgbd.getValue();
        boolean vpn = chkVpn.isSelected();

        if (nome == null || nome.isEmpty()
                || ActDire == null || ambiente == null || sgbd == null) {
            exebirAlerta("Atenção", "Preencha os campos obrigatórios (Nome, AD, Ambiente e SGBD).", AlertType.WARNING);
            return;
        }
        int qntServer = 0;
        try {
            if (qntServerStr != null && !qntServerStr.isEmpty()) {
                qntServer = Integer.parseInt(qntServerStr);
            }
        } catch (NumberFormatException e) {
            exebirAlerta("Erro", "A quantidade de servidores deve ser um número.", AlertType.ERROR);
            return;
        }

        // 3. Salvar no Banco de Dados
        String sql = "insert into clientes_dedicados (cliente, cnpj_cpf, qnt_de_servs, ad, ambiente, vpn, sgbd) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conexao = conectar();
             PreparedStatement comando = conexao.prepareStatement(sql)) {
            
            // Trocamos as interrogações (?) pelos valores reais da tela de forma segura
            comando.setString(1, nome);
            comando.setString(2, cnpj);
            comando.setInt(3, qntServer);
            comando.setString(4, ActDire);
            comando.setString(5, ambiente);
            comando.setBoolean(6, vpn);
            comando.setString(7, sgbd);
            
            comando.executeUpdate(); // Manda executar!
            
            exebirAlerta("Sucesso", "Cliente Dedicado cadastrado com sucesso!", AlertType.INFORMATION);
            fecharJanela(); // Fecha o formulário automaticamente

            } catch (SQLException e) {
            exebirAlerta("Erro no Banco", "Não foi possível salvar o cliente: " + e.getMessage(), AlertType.ERROR);
            }
        }
    @FXML
    private void cancelar(ActionEvent event){
        fecharJanela();
    }
    // Método utilitarios para fechar o pop-up
    private void fecharJanela(){
        Stage stage = (Stage) txtNome.getScene().getWindow();
        stage.close();
    }
    // Centraliza a conexão
    private Connection conectar() throws SQLException{
        return DriverManager.getConnection("jdbc:postgresql://localhost:5432/proton", "postgres", "tec@123");
    }
    
    private void exebirAlerta(String titulo, String mensagem, AlertType tipo){
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
